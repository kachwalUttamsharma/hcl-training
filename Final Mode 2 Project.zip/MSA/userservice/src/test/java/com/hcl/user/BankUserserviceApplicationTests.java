package com.hcl.user;

import java.net.URI;
import java.net.URISyntaxException;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import com.hcl.user.User;


@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment=WebEnvironment.RANDOM_PORT)
public class BankUserserviceApplicationTests {

@LocalServerPort
   int randomServerPort;

@Test
   public void testregisterUser() throws URISyntaxException
   {
       RestTemplate restTemplate = new RestTemplate();
       
       final String baseUrl = "http://localhost:"+randomServerPort+"/user/registeruser";
       
       User us=new User(2,"naven","anushka","meesalanaveen","hyderabad","india","naveen@gmail.com");
       URI uri = new URI(baseUrl);
       try {
           ResponseEntity<String> result = restTemplate.postForEntity(uri, us,String.class);
           //Verify request succeed
           
           Assert.assertEquals(200, result.getStatusCodeValue());
           Assert.assertEquals(true, result.getBody().contains("Application has been submitted"));
           }  catch(HttpClientErrorException ex)  {
            System.out.println(ex.getRawStatusCode());
               //Verify bad request and missing header
               Assert.assertEquals(404, ex.getRawStatusCode());
           }
           //Verify request succeed
         
       }


@Test
   public void testGetEmployeeListSuccessWithHeaders() throws URISyntaxException
   {
       RestTemplate restTemplate = new RestTemplate();
       
       final String baseUrl = "http://localhost:"+randomServerPort+"/User/getUser/uttam";
       URI uri = new URI(baseUrl);
       
       HttpHeaders headers = new HttpHeaders();
       

       HttpEntity<User> requestEntity = new HttpEntity<>(null, headers);

       try
       {
           restTemplate.exchange(uri, HttpMethod.GET, requestEntity, String.class);
           Assert.fail();
       }
       catch(HttpClientErrorException ex)
       {
           //Verify bad request and missing header
           Assert.assertEquals(200, ex.getRawStatusCode());
 
       }
   }
   


         
        } 