package com.hcl.user;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;




@RestController
@RequestMapping("/user")
public class UserController {
	
	private static final Logger logger = Logger
			.getLogger(UserController.class);

			public UserController() {
			System.out.println("UserController()");
			}
	@Autowired
	UserService userService;
	@RequestMapping("/getUser/{name}")
	public User getUser(@PathVariable("name") String name) {
		logger.info("get the user");
		return userService.getUserByName(name);
	}
	@RequestMapping("/registerUser")
	public ResponseEntity<String> registerUser(@RequestBody User user) {
		logger.info("register the user");
		return new ResponseEntity<String>(userService.registerUser(user), new HttpHeaders(), HttpStatus.OK);
	}
}
