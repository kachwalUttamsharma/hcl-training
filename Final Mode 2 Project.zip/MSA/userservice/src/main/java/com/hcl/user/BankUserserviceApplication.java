package com.hcl.user;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankUserserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankUserserviceApplication.class, args);
	}

}
