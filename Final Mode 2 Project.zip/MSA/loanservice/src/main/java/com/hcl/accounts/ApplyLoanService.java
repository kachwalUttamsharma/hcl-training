package com.hcl.accounts;

import java.util.List;

public interface ApplyLoanService {
	public String applyLoan(ApplyLoan al);
	public int getAppNo();
	public List<ApplyLoan> getAllLoans(int userId);
}
