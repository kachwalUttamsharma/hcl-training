package com.hcl.accounts;

import java.util.ArrayList;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class ApplyLoanServiceImpl implements ApplyLoanService {
	@Autowired
	ApplyLoanRepository applyLoanRepository;
	
	@Override
	public String applyLoan(ApplyLoan acc) {

		ApplyLoan temp=applyLoanRepository.save(acc);
				String str="";
				if (temp != null) {
					str= "Application has been submitted";
				} else {
					str= "Not submitted";
				}
			
			return str;
	}

	@Override
	public int getAppNo() {
		List<ApplyLoan> lst=new ArrayList<ApplyLoan>();
		lst=(List<ApplyLoan>) applyLoanRepository.findAll();
		return lst.size()+1;
	}

	@Override
	public List<ApplyLoan> getAllLoans(int userId) {
		List<ApplyLoan> lst=new ArrayList<ApplyLoan>();
		lst=applyLoanRepository.getApplyLoanByUserId(userId);
		return lst;
	}

}
