package com.hcl.client;

import java.util.List;

public interface ApplyLoanServiceClient {
	public String applyLoan(ApplyLoan al);
	public int getAppId();
	public List<ApplyLoan> getAllLoans(int id);
}
