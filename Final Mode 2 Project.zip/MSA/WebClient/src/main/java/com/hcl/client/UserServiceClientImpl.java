package com.hcl.client;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;



public class UserServiceClientImpl implements UserServiceClient {
	
	@Autowired
	protected RestTemplate restTemplate;
	
	protected String serviceUrl;
	
	public UserServiceClientImpl(String serviceUrl) {
		this.serviceUrl = serviceUrl.startsWith("http") ? serviceUrl: "http://" + serviceUrl;
	}
	

	@Override
	public User getUserByName(String name) {
		User user=restTemplate.getForObject(serviceUrl+"/user/getUser/{name}", User.class,name);
		return user;
	}


	@Override
	public boolean knockOut(ApplyLoan application) {
		
		boolean bool1=false,bool;
		boolean bool2=false,bool3=false;
		String str;
		int property=0;
		if(application.getCivicScore()>=95) {
			bool1=true;
		} 
		if(application.getResidency().equalsIgnoreCase("India")) {
			bool2=true;
		} else {
			str="Sorry, we can't provide loan in your country";
			bool2=false;
		}
		if(application.getPropertyType().equalsIgnoreCase("Land")) {
			if(application.getAreaCode()<=400) {
				property=(int) (application.getPropertyAmount()*100000);
			}
			else {
				property=(int) (application.getPropertyAmount()*200000);
			}
			if(application.getLoanAmount()<=property) {
				bool3=true;
			}
		}
		if(application.getPropertyType().equalsIgnoreCase("Gold")) {
			property=(int) (application.getPropertyAmount()*1000000);
			if(application.getLoanAmount()<=property) {
				bool3=true;
			}
		}
		
		if(bool1 && bool2 && bool3) {
			bool=true;
		}
		else {
			bool=false;
		}
		return bool;
		
	}


	@Override
	public String registerUser(User user) {
		ResponseEntity<String> st=restTemplate.postForEntity(serviceUrl+"/user/registerUser", user, String.class);
		return st.getBody();
		
	}


	
}

	


