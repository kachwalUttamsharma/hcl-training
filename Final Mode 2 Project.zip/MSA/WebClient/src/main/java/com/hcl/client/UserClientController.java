package com.hcl.client;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
public class UserClientController {
	private static final Logger logger = Logger
			.getLogger(UserClientController.class);

			public UserClientController() {
			System.out.println("UserClientController()");
			}
	
	
	@Autowired
	UserServiceClient userServiceClient;
	
	@Autowired
	ApplyLoanServiceClient applyLoanServiceClient;
	
	int id;
	
	@RequestMapping("/")
	public ModelAndView home(ModelAndView model){

		logger.info(" displaying the home");
		User user = new User();
		model.addObject("msg","");

		model.addObject("user", user);
		model.setViewName("login");
		return model;
	}
	
	@RequestMapping("/home")
	public ModelAndView  loginAccount(@ModelAttribute Login user,ModelAndView model) {
		logger.info("get into login account");
		User user1=new User();
		user1=userServiceClient.getUserByName(user.getUserName());
		logger.info("getting the username");
		if(user1!=null) {
		String passWord=user1.getPassWord();
		id=userServiceClient.getUserByName(user.getUserName()).getId();
		if(user.getPassWord().equals(passWord)) {
			logger.info("checking the username and password is equal");
			return new ModelAndView("redirect:/homePage1");
		} else {
			User user2 = new User();
			logger.info(" checks the password");
			model.addObject("msg","Incorrect password");
			model.addObject("user", user2);
			model.setViewName("login");
			return model;
			
		}
		} else {
			User user2 = new User();
			logger.info(" checks the username is correct or not");
			model.addObject("msg","Incorrect username");
			model.addObject("user", user2);
			model.setViewName("login");
			return model;
		}
	}
	@RequestMapping(value="/homePage1",  method = RequestMethod.GET)
	public ModelAndView  home1(ModelAndView model) {
		logger.info("entering into dashboard");
		
		model.setViewName("dashboard");
		return model;
	}
	@RequestMapping(value = "/saveApplication", method = RequestMethod.POST)
	public ModelAndView saveApplication(@ModelAttribute ApplyLoan application,ModelAndView model) {
		logger.info("enterig into save application method");
		String st,st1="";
		
		boolean bool;
		if (application.getUserId()>0) { 
			bool=userServiceClient.knockOut(application);
			logger.info("validations are checked here");
			if(bool==true) {
			 st=applyLoanServiceClient.applyLoan(application);
			 st1="Congrats, you are elegible for loan";
			} else {
				st1="Sorry, you are not eligible";
			}
		} 

		ApplyLoan al=new ApplyLoan();
		model.addObject("msg",st1);
		model.addObject("loanApp",al);
		model.setViewName("applyLoan");
		return model;
		
	}
	@RequestMapping(value="/ApplyLoan",  method = RequestMethod.GET)
	public ModelAndView  goToApplyLoan(ModelAndView model) {
		logger.info("entering to apply loan");
		ApplyLoan al=new ApplyLoan();
		al.setUserId(id);
		int appId=applyLoanServiceClient.getAppId();
		al.setApplicationId(appId);
		String str="";
		model.addObject("msg",str);
		model.addObject("loanApp",al);
		model.setViewName("applyLoan");
		return model;
	}
	@RequestMapping(value = "/register", method = RequestMethod.GET)
	public ModelAndView registerUser(ModelAndView model) {
		logger.info("entering into register");
		User user=new User();
		String str="";
		model.addObject("msg",str);
		model.addObject("user1",user);
		model.setViewName("register");
		return model;
		
	}
	@RequestMapping(value = "/saveRegister", method = RequestMethod.POST)
	public ModelAndView saveRegister(@ModelAttribute User user1,ModelAndView model) {
		logger.info("saving the registered details");
		String str="";
		
			
			str=userServiceClient.registerUser(user1);
			
		
		
			User user=new User();
			model.addObject("msg",str);
			model.addObject("user1",user);
			model.setViewName("register");
			return model;
		
	}
	@RequestMapping(value = "/calculateMortgage", method = RequestMethod.GET)
	public ModelAndView claculateMortgage(ModelAndView model) {
		logger.info("entering into mortgage calculator");
		
		model.setViewName("mortageCalc");
		return model;
		
	}
	@RequestMapping(value = "/moratageoffer", method = RequestMethod.GET)
	public ModelAndView fetchOffer(ModelAndView model) {
		logger.info("entering into mortgage offer"); 
	ApplyLoan a=new ApplyLoan();
	int loan=a.getLoanAmount();
	model.addObject("loanAmount",loan);
	model.setViewName("MortgageOffer");
	return model;
	}
	@RequestMapping(value = "/offersMortgage", method = RequestMethod.GET)
	public ModelAndView MoratageOffer(ModelAndView model)
	{
	model.setViewName("mortageoffer");
	return model;
	}
	
	@RequestMapping(value = "/loanStatus", method = RequestMethod.GET)
	public ModelAndView listExam(ModelAndView model){
		

		List<ApplyLoan> listLoan = applyLoanServiceClient.getAllLoans(id);
		model.addObject("loanStatus", listLoan);
		model.setViewName("LoanStatus");
		return model;
	}

}
	
	

