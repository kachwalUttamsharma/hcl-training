package com.hcl.client;


public class ApplyLoan {
	private static final long SerialVersionUID=1L;

	private int applicationId;
	private int userId;
	private String name;
	private int loanAmount;
	private String propertyType;
	private float propertyAmount;
	private int civicScore;

	private int areaCode;

	private String residency;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getLoanAmount() {
		return loanAmount;
	}
	public void setLoanAmount(int loanAmount) {
		this.loanAmount = loanAmount;
	}
	public String getPropertyType() {
		return propertyType;
	}
	public void setPropertyType(String propertyType) {
		this.propertyType = propertyType;
	}
	public float getPropertyAmount() {
		return propertyAmount;
	}
	public void setPropertyAmount(float propertyAmount) {
		this.propertyAmount = propertyAmount;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public int getCivicScore() {
		return civicScore;
	}
	public void setCivicScore(int civicScore) {
		this.civicScore = civicScore;
	}
	public int getAreaCode() {
		return areaCode;
	}
	public void setAreaCode(int areaCode) {
		this.areaCode = areaCode;
	}
	public String getResidency() {
		return residency;
	}
	public void setResidency(String residency) {
		this.residency = residency;
	}
	public int getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(int applicationId) {
		this.applicationId = applicationId;
	}
	
	
	
	
}
